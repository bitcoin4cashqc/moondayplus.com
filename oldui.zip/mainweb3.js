
window.contractAddress = '0xCB696c86917175DfB4F0037DDc4f2e877a9F081A';

window.crowdsaleAddress = '0x8aB4657A160c1F8a78a03AC598E5F3C2Fd0c2882';

window.stakeAddress = '0x6dBD235B85Cb1678FB5ECF56029EfF663B4b8fBF';


//window.poolAddr = '0xcfb8cf118b4f0abb2e8ce6dbeb90d6bc0a62693d';


let contract

let crowdsale

let stake

//let pool

let loop = false

let APIKeys = {
infura: "ef0b2636c2494195b8e4c5a1f021ca7a",
etherscan: "E7EQBY2CKAM2153E5728JSAC4GX7VIHBSQ"
}

/* ------------------------------ */

// Unpkg imports
const Web3Modal = window.Web3Modal.default;
const WalletConnectProvider = window.WalletConnectProvider.default;

// Web3modal instance
let web3Modal

// Chosen wallet provider given by the dialog window
let provider;

// Address of the selected account
window.userAddr = null;

function initProviders() {
    console.log("WalletConnectProvider is", WalletConnectProvider);

    // Tell Web3modal what providers we have available.
    // Built-in web browser provider (only one can exist as a time)
    // like MetaMask, Brave or Opera is added automatically by Web3modal
    const providerOptions = {
      walletconnect: {
        package: WalletConnectProvider,
        options: {
          infuraId: APIKeys.infura,
          // bridge: 'https://bridge.walletconnect.org',
        }
      },

    };

    web3Modal = new Web3Modal({
      cacheProvider: true, // optional
      providerOptions, // required
      theme: {
        background: "#252f5a",
        main: "#fff",
        secondary: "rgb(199, 199, 199)",
        border: "rgba(195, 195, 195, 0.14)",
        hover: "rgb(16, 26, 32)"
      },
    });

}


/**
 * Kick in the UI action after Web3modal dialog has chosen a provider
 */
async function fetchAccountData() {

  // Get a Web3 instance for the wallet
  window.web3 = new Web3(provider);

  console.log("Web3 instance is", web3);

  // Get connected chain id from Ethereum node
  window.chainId = (web3.eth.getChainId) ? await web3.eth.getChainId() : 1;

  // Get list of accounts of the connected wallet
  const accounts = await web3.eth.getAccounts();

  // MetaMask does not give you all accounts, only the selected account
  console.log("Got accounts", accounts);
  userAddr = accounts[0];
  
   
  //document.querySelector("#selected-account").textContent = shortenAddr(userAddr);

  // const accountRowTemplate = document.querySelector("#template-account-row");
  // const accountContainer = document.querySelector("#accounts");
  //
  // // Purge UI elements any previously loaded accounts
  // accountContainer.innerHTML = '';
  //
  // // Go through all accounts and get their ETH balance
  // const rowResolvers = accounts.map(async (address) => {
  //   const balance = await web3.eth.getBalance(address);
  //   // ethBalance is a BigNumber instance
  //   // https://github.com/indutny/bn.js/
  //   const ethBalance = web3.utils.fromWei(balance, "ether");
  //   const humanFriendlyBalance = parseFloat(ethBalance).toFixed(4);
  //   // Fill in the templated row and put in the document
  //   const clone = accountRowTemplate.content.cloneNode(true);
  //   clone.querySelector(".address").textContent = address;
  //   clone.querySelector(".balance").textContent = humanFriendlyBalance;
  //   accountContainer.appendChild(clone);
  // });
  //
  // // Because rendering account does its own RPC commucation
  // // with Ethereum node, we do not want to display any results
  // // until data for all accounts is loaded
  // await Promise.all(rowResolvers);

  // Display fully loaded UI for wallet data
  $("#prepare").hide()
  $("#connected").show()

  if (!userAddr) {
    return false
  }
  return true
}



/**
 * Fetch account data for UI when
 * - User switches accounts in wallet
 * - User switches networks in wallet
 * - User connects wallet initially
 */
async function refreshAccountData() {
  console.log('refreshAccountData')

  // If any current data is displayed when
  // the user is switching acounts in the wallet immediate hide this data
  $("#connected").hide()
  $("#prepare").show()

  // Disable button while UI is loading.
  document.querySelector("#btn-connect").setAttribute("disabled", "disabled")
  await fetchAccountData(provider);
  document.querySelector("#btn-connect").removeAttribute("disabled")
   $("#ethwallet").val(userAddr)
}


async function onConnect() {
  console.log('onConnect')

  try {
    provider = await askConnect();
  } catch(e) {
    console.log("Could not get a wallet connection", e);
    return;
  }

  await afterConnect()
}

async function onDisconnect() {

  console.log("Killing the wallet connection", provider);

  loop = false

  if (provider.close) {
    await provider.close();

    provider = null;
  }
  console.log('Clearing cached provider')
  // If the cached provider is not cleared,
  // WalletConnect will default to the existing session
  // and does not allow to re-scan the QR code with a new wallet.
  // Depending on your use case you may want or want not his behavir.
  await web3Modal.clearCachedProvider();

  userAddr = null;

  // Set the UI back to the initial state
  $("#prepare").show()
  $("#connected").hide()
}


/* ------------------------------ */

async function isConnected() {
  const connected = !!window.provider
  console.log('isConnected? ', connected)
  return connected

  if (userAddr) { return true; }
  try {
    const accounts = await web3.eth.getAccounts();
    return (Array.isArray(accounts) && accounts.length > 0)
  } catch (err) {
    console.error(err)
    return false
  }
}

async function init() {
  setTimeout(() => { $('#btn-connect').css('opacity', 1); }, 1000)
  setTimeout(() => {
    $('.uniswap-link').attr('href', uniswapUrl())
  }, 0)
  
  initProviders()
  if (web3Modal.cachedProvider) {
    console.log('cachedProvider, connecting...')
    await web3Modal.connect();
    provider = web3Modal.cachedProvider
  }

  // if (window.ethereum) {
  //   window.web3 = new Web3(ethereum);
  // }
  // // Legacy dapp browsers...
  // else if (window.web3) {
  //   window.web3 = new Web3(web3.currentProvider);
  //   // Acccounts always exposed
  // }

  if (await isConnected()) {
    await afterConnect()
  } else {
    await askConnect()
    await afterConnect()
  }

}
window.addEventListener('load', init);


async function askConnect() {
  console.log('askConnect')
  try {
    // await ethereum.enable() // Request access
    provider = await web3Modal.connect()

    toggleConnected(true);
    return provider

  } catch (error) {
    // User denied account access...
    console.error('Enable error: ', error)
    if (error.code === 4001) {
      toggleConnected(false);
    }
    return null
  }
}

async function afterConnect() {
  // Subscribe to accounts change
  provider.on("accountsChanged", async (accounts) => {
    if (!await fetchAccountData()) {
      await onDisconnect()
    }
  });
  // Subscribe to chainId change
  provider.on("chainChanged", async (chainId) => {
    if (!await fetchAccountData()) {
      await onDisconnect()
    }
  });
  // Subscribe to networkId change
  provider.on("networkChanged", async (networkId) => {
    if (!await fetchAccountData()) {
      await onDisconnect()
    }
  });
  await refreshAccountData();

  await setupContracts()
  loop = true
  await interfaceLoop()
  updateLiveEvents()
  fastLoop()
}

async function setupContracts() {
  try {
    // Initialize contracts

    contract = await new web3.eth.Contract(abis[contractAddress], contractAddress)

    crowdsale = await new web3.eth.Contract(abis[crowdsaleAddress], crowdsaleAddress)

    stake = await new web3.eth.Contract(abis[stakeAddress], stakeAddress)


    //pool = await new web3.eth.Contract(abis[poolAddr], poolAddr)
    //await getRecentEvents()
    //await listen()
  } catch(error) { console.error(error) }
}



function addCommas(x) {
  return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',')
}

function formatTokens(num) {
  return addCommas((num / 1e18).toFixed(2))+" MD+"
}



let ethUsd = 313
let res
let dollarPrice
let ethPrice

function formatDollas(amount) {
  if (amount < 0) {
      return '-$' + addCommas((Math.abs(amount)).toFixed(3))
  }
  return '~$' + addCommas((amount).toFixed(3))
}

function formatD(amount) {
  return ' ($' + addCommas((amount).toFixed(0)) + ' USD)'
}


function secondsToDhms(seconds) {
seconds = Number(seconds);
var d = Math.floor(seconds / (3600*24));
var h = Math.floor(seconds % (3600*24) / 3600);
var m = Math.floor(seconds % 3600 / 60);
var s = Math.floor(seconds % 60);

var dDisplay = d > 0 ? d + (d == 1 ? " day, " : " days, ") : "";
var hDisplay = h > 0 ? h + (h == 1 ? " hour, " : " hours, ") : "";
var mDisplay = m > 0 ? m + (m == 1 ? " minute, " : " minutes, ") : "";
var sDisplay = s > 0 ? s + (s == 1 ? " second" : " seconds") : "";
return dDisplay + hDisplay + mDisplay + sDisplay;
}

function uniswapUrl() {
  return `https://app.uniswap.org/#/swap?outputCurrency=${window.contractAddress}`
}


async function updateEthUsd() {
  try {
    const res = await fetch('https://api.coingecko.com/api/v3/simple/price?ids=ethereum&vs_currencies=USD')
    const json = await res.json()
    ethUsd = json.ethereum.usd
  } catch(err) {
    console.error(err)
  }
}

async function interfaceLoop() {
  if (!loop) { return }
  try {
    updateEthUsd()

    //res = await pool.methods.getReserves().call()
    //$('.totalEthLiq').text(formatTokens(res[1]) + ' ETH')

    //ethPrice = res[1] / res[0]
    //dollarPrice = ethPrice * ethUsd
    //$('.usdPrice').text('~$' + (dollarPrice).toFixed(5))
    //$('.ethPrice').text((ethPrice).toFixed(6) + ' ETH')

   

    //get wei raised
    //let data = await contract.methods.getInfoFor(userAddr).call()
   
    
    //let userTokens = Number(g['balance'])
 
    //$('.walletTokens').text(formatTokens(userTokens) + formatD(userTokens/1e18 * dollarPrice))

    //$('.totalRewards').text(formatTokens(g['allTimeRewards']) + formatD(g['allTimeRewards']/1e18 * dollarPrice))

    //$('.rewardPool').text(formatTokens(g['rewardPool']) + formatD(g['rewardPool']/1e18 * dollarPrice))


    //$('.totalGrilled').text(formatTokens(g['totalGrilled']))

    //get wei raised
    let ethraised = await crowdsale.methods.weiRaised().call()

    ethraised = formatWhole(ethraised)
      

    $('#ethraised').text(ethraised)


    var ethhard = 57.92180625-ethraised
    

    $('#ethhard').text(ethhard.toFixed(2))


    $('#ethpriceimo').html(0.0468055 +" ETH/MD+ "+ formatD(0.0468055 * ethUsd))

    
    let userBl = await contract.methods.balanceOf(userAddr).call()

    userBl = formatWhole(userBl)

    $('#userBl').text(userBl)




    //get status

    let whiteliststatus = await crowdsale.methods.isWithinCappedSaleWindow().call()
    let wholestatus = await crowdsale.methods.hasEnded().call()

    if(whiteliststatus){
      $('#salestatus').text("Waiting IMO")
    }else{
      

      if(!wholestatus){
      $('#salestatus').text("IMO")
      }else{
        $('#salestatus').text("ENDED")
      }


    }
   


     

    let userReward = await stake.methods.getUserAvailable(userAddr).call()

    userReward = formatWhole(userReward)
    $('#userReward').text(userReward)



    let userTotalDepam = await stake.methods.getUserAmountOfDeposits(userAddr).call()

    //mask affiliate if not available

    if(userTotalDepam > 0){

      $("#yourrefferal").val("https://www.moondayplus.com/?a="+userAddr)

    }else{

      $("#yourrefferal").val("Deposit before sharing your link")

    }



    $('#userTotalDeps').text(userTotalDepam)


    let userTotalDep = await stake.methods.getUserTotalDeposits(userAddr).call()

    userTotalDep = formatWhole(userTotalDep)
    $('#userTotalDep').text(userTotalDep)


    let userTotalWith = await stake.methods.getUserTotalWithdrawn(userAddr).call()

    userTotalWith = formatWhole(userTotalWith)
    $('#userTotalWith').text(userTotalWith)

  
    let totalUsers = await stake.methods.totalUsers().call()

    
    $('#totalUsers').text(totalUsers)

    let totalInvested = await stake.methods.totalInvested().call()

    totalInvested = formatWhole(totalInvested)
    $('#totalInvested').text(totalInvested)

    let totalWith = await stake.methods.totalWithdrawn().call()

    totalWith = formatWhole(totalWith)
    $('#totalWith').text(totalWith)

    let totalDeposits = await stake.methods.totalDeposits().call()

    
    $('#totalDeposits').text(totalDeposits)
    


    

   
    if (loop) {
      setTimeout(interfaceLoop, 2000)
    }
  } catch(error) {
    console.log(error)
    if (loop) {
      setTimeout(interfaceLoop, 2000)
    }
  }
}

async function fastLoop () {
  if (!loop) { return }
  
    

  if (loop) {
    setTimeout(fastLoop, 100)
  }
}




function contribute() {
  web3.eth.sendTransaction({from: userAddr, to:crowdsaleAddress, value: web3.utils.toWei($('#amounteth').val(), 'ether'), gasLimit: 121000})
}


var affiliate = getUrlParameter('a');

if(typeof affiliate != 'undefined'){

  $("#refferal").val(affiliate)

}else{
$("#refferal").val("0x0000000000000000000000000000000000000000")
}

async function stakes() {



let amount = web3.utils.toWei($("#mdstakes").val())



await stake.methods.invest($("#refferal").val(),amount).send({from:userAddr})


}



function getUrlParameter(sParam) {
    var sPageURL = window.location.search.substring(1),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : decodeURIComponent(sParameterName[1]);
        }
    }
};



async function withdraws() {
  await stake.methods.withdraw().send({from: userAddr})
}


function transfer() {
  let amount = web3.utils.toWei($('#transferInput').val())
 

  contract.methods.transfer($('#transferAddr').val(), amount).send({from:userAddr})
}



let recentEvents = []
let usedIds = []

async function getRecentEvents() {
  let b = await web3.eth.getBlockNumber() - 3000
  let contractEv = await contract.getPastEvents('allEvents',{fromBlock:b,toBlock:'latest'})
  let poolEv = await pool.getPastEvents('Swap',{fromBlock:b,toBlock:'latest'})
  recentEvents = [...contractEv, ...poolEv].sort((a, b) => a.blockNumber - b.blockNumber).reverse()
  recentEvents = recentEvents.filter(item => item.event !== 'Transfer')
  recentEvents = recentEvents.filter(item => item.event !== 'Approval')
  recentEvents = recentEvents.filter(item => item.event !== 'PoolGrill')

}

// timeX, typeX, imgX, amountX, linkX, txX
// assets/img/smalllogo.png / newlogo.png
// buy = green-text, stake = no class
// ignite = burn-text, sell = red-text
// unstake = grey-text

function formatDSimple(amount) {
  return '$' + addCommas((amount).toFixed(2))
}

function formatWhole(amount) {

  return (amount / 1e18).toFixed(4)

}

function updateLiveEvents() {
  // buys first
  let len = recentEvents.length
  if (len > 20) {
    len = 20
  }
  for (i=0; i < len; i++) {
    $('#type'+(i+1)).removeClass()
    let e = recentEvents[i]
    var width = $(window).width();
    $('#link'+(i+1)).attr('href', 'https://etherscan.io/tx/' + e.transactionHash)
    $('#tx'+(i+1)).text(e.transactionHash.slice(0,4) + '..')
    if (width >= 600 && width <= 980) {
      $('#tx'+(i+1)).text(e.transactionHash.slice(0,10) + '..')
    } else if (width > 980) {
      $('#tx'+(i+1)).text(e.transactionHash.slice(0,20) + '..')
    }
    usedIds.push(e.transactionHash)
    switch (e.event) {
      case 'Swap':
        if (e.returnValues.amount0Out != '0') {
          // buy
         // $('#user'+(i+1)).text(e.returnValues.to.slice(0,6) + '..')
          $('#type'+(i+1)).addClass('green-text')
          //$('#type'+(i+1)).text('Buy')
          $('#type'+(i+1)).text('Buy ' + formatDSimple(e.returnValues.amount1In/1e18 * ethUsd))
          $('#img'+(i+1)).attr('src','assets/img/smalllogo.png')
          $('#amount'+(i+1)).text(formatTokens(e.returnValues.amount0Out))
        } else {
          // sell
         // $('#user'+(i+1)).text(e.returnValues.sender.slice(0,6) + '..')
          $('#type'+(i+1)).addClass('red-text')
          //$('#type'+(i+1)).text('Sell')
          $('#type'+(i+1)).text('Sell ' + formatDSimple(e.returnValues.amount1Out/1e18 * ethUsd))
          $('#img'+(i+1)).attr('src','assets/img/smalllogo.png')
          $('#amount'+(i+1)).text(formatTokens(e.returnValues.amount0In))
        }
        break
      case 'PoolBurn':
        //$('#user'+(i+1)).text(e.returnValues.user.slice(0,6) + '..')
        $('#type'+(i+1)).addClass('burn-text')
        $('#type'+(i+1)).text('Ignite')
        $('#img'+(i+1)).attr('src','assets/img/newlogo.png')
        $('#amount'+(i+1)).text(formatTokens(e.returnValues.burned))
        break
      case 'Stake':
        //$('#type'+(i+1)).addClass('green-text')
        //$('#user'+(i+1)).text(e.returnValues.user.slice(0,6) + '..')
        $('#type'+(i+1)).text('Stake')
        $('#img'+(i+1)).attr('src','assets/img/smalllogo.png')
        $('#amount'+(i+1)).text(formatTokens(e.returnValues.staked))
        break
      case 'Unstake':
        //$('#user'+(i+1)).text(e.returnValues.user.slice(0,6) + '..')
        $('#type'+(i+1)).addClass('grey-text')
        $('#type'+(i+1)).text('Unstake')
        $('#img'+(i+1)).attr('src','assets/img/smalllogo.png')
        $('#amount'+(i+1)).text(formatTokens(e.returnValues.unstaked))
        break
    }
  }
}

async function listen() {
  contract.events.allEvents(function(e, result) {
    if (result.event == 'PoolGrill' || result.event == 'PayoutClaimed') {
    //if (result.event == 'Stake' || result.event == 'Unstake') {
    if (!usedIds.includes(result.transactionHash)) {
        recentEvents.unshift(result)
        updateLiveEvents()
      }
    }
  })
  pool.events.Swap(function(e, result) {
    if (!usedIds.includes(result.transactionHash)) {
      recentEvents.unshift(result)
      updateLiveEvents()
    }
  })
}






function shortenAddr(addr) {
  return addr.slice(0, 6) + "..." + addr.slice(-4)
}

function toggleConnected(forceTo) {
}